import React, { useState } from 'react';
import { HelpCircle, ChevronDown, ChevronUp, Smartphone, ShieldCheck, Volume2, Search } from 'lucide-react';
import { useLanguage } from '../i18n/LanguageContext';

export const HelpPage: React.FC = () => {
  const { t } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'How do I download the Android APK to my phone?',
      a: 'Click "Install App" or "Download APK (Android)" anywhere in the header or install page. The APK file (PocketKit-release.apk) will immediately download to your phone. Open the downloaded file from your notifications or Downloads folder to install. If prompted, allow "Install from this source" in your Android settings.',
    },
    {
      q: 'How do I install PocketKit on iPhone or iPad (iOS)?',
      a: 'Open PocketKit in the Safari browser on your iOS device. Tap the Share button (square icon with an arrow pointing up), scroll down in the share sheet, and tap "Add to Home Screen". PocketKit will appear on your home screen as a full-screen app with offline capabilities.',
    },
    {
      q: 'Is my data secure and private?',
      a: 'Yes, 100%. PocketKit operates completely client-side in your device browser. When you encrypt text, compress images, or calculate taxes, nothing leaves your device. We do not operate remote processing servers for your data.',
    },
    {
      q: 'How can visually impaired or non-literate users use the tools?',
      a: 'Every tool includes a "Listen 🔊" or audio guide button. Simply click this button and the app will read instructions, tool labels, and calculated results aloud in your selected language.',
    },
    {
      q: 'Does PocketKit work without an internet connection?',
      a: 'Yes! Once you visit PocketKit, the Progressive Web App (PWA) caches all necessary assets. You can open and use all tools without any WiFi or cellular data connection.',
    },
    {
      q: 'Can I use keyboard shortcuts?',
      a: 'Yes. Press Ctrl+K (or Command+K on Mac) anywhere to open the rapid search modal. You can also press Escape (ESC) to quickly close any opened tool modal.',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      <div className="space-y-2 text-center">
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 dark:text-white">
          Help & Frequently Asked Questions
        </h1>
        <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base">
          Guides for Android APK installation, PWA setup, audio accessibility, and offline usage.
        </p>
      </div>

      <div className="space-y-3">
        {faqs.map((item, idx) => (
          <div
            key={idx}
            className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-[#1a202c] overflow-hidden"
          >
            <button
              onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
              className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm sm:text-base text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
            >
              <span>{item.q}</span>
              {openIndex === idx ? (
                <ChevronUp className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
              ) : (
                <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
              )}
            </button>
            {openIndex === idx && (
              <div className="px-5 pb-5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800 pt-3">
                {item.a}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
