import React, { useState } from 'react';
import { Delete, RotateCcw, Volume2, Sparkles } from 'lucide-react';
import { useLanguage } from '../../i18n/LanguageContext';

export const CalculatorTool: React.FC = () => {
  const [display, setDisplay] = useState('0');
  const [equation, setEquation] = useState('');
  const { t, speak } = useLanguage();

  const handleDigit = (digit: string) => {
    setDisplay((prev) => (prev === '0' ? digit : prev + digit));
  };

  const handleOperator = (op: string) => {
    setEquation(`${display} ${op} `);
    setDisplay('0');
  };

  const handleEqual = () => {
    try {
      const full = `${equation}${display}`;
      // Clean safe math eval
      const cleanExpr = full.replace(/×/g, '*').replace(/÷/g, '/');
      const sanitized = cleanExpr.replace(/[^0-9+\-*/.() ]/g, '');
      const result = Function(`'use strict'; return (${sanitized})`)();
      setDisplay(String(result));
      setEquation('');
      speak(`Result is ${result}`);
    } catch {
      setDisplay('Error');
    }
  };

  const handleClear = () => {
    setDisplay('0');
    setEquation('');
  };

  const handleBackspace = () => {
    setDisplay((prev) => (prev.length > 1 ? prev.slice(0, -1) : '0'));
  };

  return (
    <div className="max-w-md mx-auto space-y-4">
      {/* Display Screen */}
      <div className="p-4 rounded-2xl bg-slate-900 text-white text-right font-mono border-2 border-slate-800 shadow-inner">
        <div className="h-6 text-xs text-slate-400 truncate">{equation}</div>
        <div className="text-3xl sm:text-4xl font-black text-emerald-400 truncate mt-1">
          {display}
        </div>
      </div>

      {/* Calculator Keypad */}
      <div className="grid grid-cols-4 gap-2.5">
        <button
          onClick={handleClear}
          className="p-3.5 rounded-xl font-black text-sm bg-red-100 dark:bg-red-950/60 text-red-600 dark:text-red-400 hover:bg-red-200 cursor-pointer"
        >
          AC
        </button>
        <button
          onClick={handleBackspace}
          className="p-3.5 rounded-xl font-black text-sm bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 cursor-pointer flex items-center justify-center"
        >
          <Delete className="w-4 h-4" />
        </button>
        <button
          onClick={() => handleOperator('%')}
          className="p-3.5 rounded-xl font-black text-sm bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200 cursor-pointer"
        >
          %
        </button>
        <button
          onClick={() => handleOperator('÷')}
          className="p-3.5 rounded-xl font-black text-base bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer"
        >
          ÷
        </button>

        {['7', '8', '9'].map((n) => (
          <button
            key={n}
            onClick={() => handleDigit(n)}
            className="p-3.5 rounded-xl font-black text-base bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200/80 dark:border-slate-700 cursor-pointer"
          >
            {n}
          </button>
        ))}
        <button
          onClick={() => handleOperator('×')}
          className="p-3.5 rounded-xl font-black text-base bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer"
        >
          ×
        </button>

        {['4', '5', '6'].map((n) => (
          <button
            key={n}
            onClick={() => handleDigit(n)}
            className="p-3.5 rounded-xl font-black text-base bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200/80 dark:border-slate-700 cursor-pointer"
          >
            {n}
          </button>
        ))}
        <button
          onClick={() => handleOperator('-')}
          className="p-3.5 rounded-xl font-black text-base bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer"
        >
          -
        </button>

        {['1', '2', '3'].map((n) => (
          <button
            key={n}
            onClick={() => handleDigit(n)}
            className="p-3.5 rounded-xl font-black text-base bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200/80 dark:border-slate-700 cursor-pointer"
          >
            {n}
          </button>
        ))}
        <button
          onClick={() => handleOperator('+')}
          className="p-3.5 rounded-xl font-black text-base bg-indigo-600 text-white hover:bg-indigo-700 cursor-pointer"
        >
          +
        </button>

        <button
          onClick={() => handleDigit('0')}
          className="col-span-2 p-3.5 rounded-xl font-black text-base bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200/80 dark:border-slate-700 cursor-pointer"
        >
          0
        </button>
        <button
          onClick={() => handleDigit('.')}
          className="p-3.5 rounded-xl font-black text-base bg-slate-50 dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-900 dark:text-white border border-slate-200/80 dark:border-slate-700 cursor-pointer"
        >
          .
        </button>
        <button
          onClick={handleEqual}
          className="p-3.5 rounded-xl font-black text-base bg-emerald-600 text-white hover:bg-emerald-700 shadow-sm cursor-pointer"
        >
          =
        </button>
      </div>
    </div>
  );
};
