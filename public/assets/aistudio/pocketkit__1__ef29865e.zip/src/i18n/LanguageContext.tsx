import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Language, translations, LANGUAGES } from './translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string, fallback?: string) => string;
  speak: (text: string) => void;
  stopSpeaking: () => void;
  isSpeaking: boolean;
  fontSize: 'normal' | 'large' | 'xl';
  setFontSize: (size: 'normal' | 'large' | 'xl') => void;
  highContrast: boolean;
  setHighContrast: (val: boolean) => void;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

// Map app Language code to standard BCP-47 SpeechSynthesis locale tag
const SPEECH_LANG_MAP: Record<Language, string> = {
  en: 'en-US',
  hi: 'hi-IN',
  bn: 'bn-IN',
  te: 'te-IN',
  ta: 'ta-IN',
  mr: 'mr-IN',
  gu: 'gu-IN',
  kn: 'kn-IN',
  ml: 'ml-IN',
  pa: 'pa-IN',
  ur: 'ur-PK',
  or: 'or-IN',
  es: 'es-ES',
  fr: 'fr-FR',
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('pocketkit_lang');
    if (saved && saved in translations) {
      return saved as Language;
    }
    // Try browser language
    const navLang = navigator.language.split('-')[0] as Language;
    if (navLang && navLang in translations) {
      return navLang;
    }
    return 'en';
  });

  const [isSpeaking, setIsSpeaking] = useState(false);
  const [fontSize, setFontSizeState] = useState<'normal' | 'large' | 'xl'>(() => {
    const saved = localStorage.getItem('pocketkit_font_size');
    return (saved as 'normal' | 'large' | 'xl') || 'normal';
  });
  const [highContrast, setHighContrastState] = useState<boolean>(() => {
    return localStorage.getItem('pocketkit_high_contrast') === 'true';
  });

  // Sync language with localStorage & html lang
  const setLanguage = (newLang: Language) => {
    setLanguageState(newLang);
    localStorage.setItem('pocketkit_lang', newLang);
    document.documentElement.lang = newLang;
  };

  // Sync font size
  const setFontSize = (size: 'normal' | 'large' | 'xl') => {
    setFontSizeState(size);
    localStorage.setItem('pocketkit_font_size', size);
  };

  // Sync high contrast
  const setHighContrast = (val: boolean) => {
    setHighContrastState(val);
    localStorage.setItem('pocketkit_high_contrast', val ? 'true' : 'false');
  };

  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  useEffect(() => {
    const html = document.documentElement;
    html.classList.remove('font-size-large', 'font-size-xl');
    if (fontSize === 'large') html.classList.add('font-size-large');
    if (fontSize === 'xl') html.classList.add('font-size-xl');
  }, [fontSize]);

  useEffect(() => {
    const html = document.documentElement;
    if (highContrast) {
      html.classList.add('high-contrast');
    } else {
      html.classList.remove('high-contrast');
    }
  }, [highContrast]);

  // Translation lookup function
  const t = (key: string, fallback?: string): string => {
    const langDict = translations[language];
    if (langDict && langDict[key]) {
      return langDict[key];
    }
    // Fallback to English
    const enDict = translations.en;
    if (enDict && enDict[key]) {
      return enDict[key];
    }
    return fallback || key;
  };

  // Accessibility Text-to-Speech support for non-educated & visually challenged users
  const speak = (text: string) => {
    if (!('speechSynthesis' in window)) {
      return;
    }
    window.speechSynthesis.cancel();

    if (!text || !text.trim()) {
      setIsSpeaking(false);
      return;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    const bcpTag = SPEECH_LANG_MAP[language] || 'en-US';
    utterance.lang = bcpTag;
    utterance.rate = 0.95; // Slightly slower for clarity
    utterance.pitch = 1.0;

    // Pick a voice that matches language if available
    const voices = window.speechSynthesis.getVoices();
    const matchedVoice = voices.find((v) => v.lang.startsWith(language) || v.lang === bcpTag);
    if (matchedVoice) {
      utterance.voice = matchedVoice;
    }

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    setIsSpeaking(false);
  };

  return (
    <LanguageContext.Provider
      value={{
        language,
        setLanguage,
        t,
        speak,
        stopSpeaking,
        isSpeaking,
        fontSize,
        setFontSize,
        highContrast,
        setHighContrast,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
